using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Support;

namespace tutorial_Asharp
{
    public partial class Form1 : Form
    {
        // Callback declaration
        Support.CallBack Test = new CallBack();

        public Form1()
        {
            InitializeComponent();

            // Attach a callback handler
            Test.CallBackEvent += new Support.CallBackHandler(onMessageReceived);

            bob_pkg.set_callbackhandler(Test);
        }

        void onMessageReceived(object sender, CallBackEventArgs e)
        {
            MessageBox.Show("Received (" + e.MessageId + ")");
        } 

        private void button1_Click(object sender, EventArgs e)
        {
            bob_pkg.do_something();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            bob_pkg.start_timer((int)num_timer.Value);
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            bob_pkg.cancel_timer();
        }
    }
}