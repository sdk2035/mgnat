using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace tutorial_Asharp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ada_bob_pkg.adainit(); 

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            ada_bob_pkg.adafinal();   // Cleanup (and terminate tasks)
        }
    }
}