using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Support;

namespace tutorial_Asharp_cf
{
    public partial class Form1 : Form
    {
        // Callback declaration
        Support.CallBack Test = new CallBack();

        public Form1()
        {
            InitializeComponent();

            // Attach a callback handler
            Test.CallBackEvent += new Support.CallBackHandler(onMessageReceived);

            bob_pkg.set_callbackhandler(Test);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bob_pkg.do_something();
            //Test.Trigger(123);
        }

        void onMessageReceived(object sender, CallBackEventArgs e)
        {
            MessageBox.Show("Received (" + e.MessageId + ")");
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            bob_pkg.start_timer((int)num_timer.Value);
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            bob_pkg.cancel_timer();
        }
    }
}