using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace tutorial_Asharp_cf
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [MTAThread]
        static void Main()
        {
            ada_bob_pkg.adainit();
            Application.Run(new Form1());
            ada_bob_pkg.adafinal();   // Cleanup (and terminate tasks)
        }
    }
}