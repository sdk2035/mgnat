using System;

namespace Support
{
	/// <summary>
	/// This delegate provides a handle to create an event handler.
	/// </summary>
	public delegate void CallBackHandler (
	object sender, CallBackEventArgs args);

	/// <summary>
	/// Summary description for CallBack.
	/// </summary>
	public class CallBack
	{
		public event CallBackHandler CallBackEvent;

		public CallBack()
		{
		}

		/// <summary>
		/// Trigger will be called by the PzH_Handler assembly (A#).
		/// </summary>
		public void Trigger(int MessageId)
		{
			if ( CallBackEvent != null )
			{
				// Only if an eventhandler has been specified, call the handler

				// First wrap the information inside an arguments object
				CallBackEventArgs args = new CallBackEventArgs (MessageId);
				
				// make the call
				CallBackEvent (null, args);
			}
		}

		static void Main() 
		{
		}
	}

}
