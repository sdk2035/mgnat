using System;

namespace Support
{
	/// <summary>
	/// This class provides the message of the received message
	/// </summary>
	public class CallBackEventArgs
	{
		private readonly int _messageId;

		public CallBackEventArgs (
			int messageId )
		{
			_messageId = messageId;
		}

		public int MessageId
		{
			get
			{
				return _messageId;
			}
		}
	}
}
